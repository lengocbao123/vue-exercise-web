<template>
  <section class="ftco-section ftco-partner">
    <div class="container">
      <div class="row">
        <div class="col-sm ftco-animate">
          <a href="#" class="partner"
            ><img
              src="../../assets/images/partner-1.png"
              class="img-fluid"
              alt="Colorlib Template"
          /></a>
        </div>
        <div class="col-sm ftco-animate">
          <a href="#" class="partner"
            ><img
              src="../../assets/images/partner-2.png"
              class="img-fluid"
              alt="Colorlib Template"
          /></a>
        </div>
        <div class="col-sm ftco-animate">
          <a href="#" class="partner"
            ><img
              src="../../assets/images/partner-3.png"
              class="img-fluid"
              alt="Colorlib Template"
          /></a>
        </div>
        <div class="col-sm ftco-animate">
          <a href="#" class="partner"
            ><img
              src="../../assets/images/partner-4.png"
              class="img-fluid"
              alt="Colorlib Template"
          /></a>
        </div>
        <div class="col-sm ftco-animate">
          <a href="#" class="partner"
            ><img
              src="../../assets/images/partner-5.png"
              class="img-fluid"
              alt="Colorlib Template"
          /></a>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style></style>
