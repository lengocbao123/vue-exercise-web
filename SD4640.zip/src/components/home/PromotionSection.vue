<template>
  <section class="ftco-section ftco-3 img">
    <div class="container">
      <div class="row justify-content-end">
        <div
          class="col-md-6 heading-section ftco-animate deal-of-the-day ftco-animate"
        >
          <span class="subheading">Best Price For You</span>
          <h2 class="mb-4">Deal of the day</h2>
          <p>
            Far far away, behind the word mountains, far from the countries
            Vokalia and Consonantia
          </p>
          <h3><a href="#">Spinach</a></h3>
          <span class="price">$10 <a href="#">now $5 only</a></span>
          <div id="timer" class="d-flex mt-5">
            <div class="time" id="days"></div>
            <div class="time pl-3" id="hours"></div>
            <div class="time pl-3" id="minutes"></div>
            <div class="time pl-3" id="seconds"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style>
.ftco-3 {
  background-image: url(../../assets/images/bg_3.jpg);
}
</style>
