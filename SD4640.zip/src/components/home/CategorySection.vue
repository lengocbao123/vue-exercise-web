<template>
  <section class="ftco-section ftco-category ftco-no-pt">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="row">
            <div class="col-md-6 order-md-last align-items-stretch d-flex">
              <div
                class="category-0 category-wrap-2 ftco-animate img align-self-stretch d-flex"
              >
                <div class="text text-center">
                  <h2>Vegetables</h2>
                  <p>Protect the health of every home</p>
                  <p><a href="#" class="btn btn-primary">Shop now</a></p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div
                class="category-1 category-wrap ftco-animate img mb-4 d-flex align-items-end"
              >
                <div class="text px-3 py-1">
                  <h2 class="mb-0"><a href="#">Fruits</a></h2>
                </div>
              </div>
              <div
                class="category-2 category-wrap ftco-animate img d-flex align-items-end"
              >
                <div class="text px-3 py-1">
                  <h2 class="mb-0"><a href="#">Vegetables</a></h2>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div
            class="category-3 category-wrap ftco-animate img mb-4 d-flex align-items-end"
          >
            <div class="text px-3 py-1">
              <h2 class="mb-0"><a href="#">Juices</a></h2>
            </div>
          </div>
          <div
            class="category-4 category-wrap ftco-animate img d-flex align-items-end"
          >
            <div class="text px-3 py-1">
              <h2 class="mb-0"><a href="#">Dried</a></h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {};
</script>

<style>
.category-0 {
  background-image: url(../../assets/images/category.jpg);
}
.category-1 {
  background-image: url(../../assets/images/category-1.jpg);
}
.category-2 {
  background-image: url(../../assets/images/category-2.jpg);
}
.category-3 {
  background-image: url(../../assets/images/category-3.jpg);
}
.category-4 {
  background-image: url(../../assets/images/category-4.jpg);
}
</style>
