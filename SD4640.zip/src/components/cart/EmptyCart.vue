<template>
  <div class="text-center">
    <p>Your cart is empty</p>
    <router-link to="/">Add products to cart</router-link>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
