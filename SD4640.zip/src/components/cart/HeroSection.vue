<template>
  <div
    class="hero-wrap hero-bread"
    style="
      background-image: url('https://ik.imagekit.io/gsozk5bngn/bg_1_5K_RFzNMgmJ.jpg?updatedAt=1640838659746');
    "
  >
    <div class="container">
      <div
        class="row no-gutters slider-text align-items-center justify-content-center"
      >
        <div class="col-md-9 ftco-animate text-center">
          <p class="breadcrumbs">
            <span class="mr-2"><router-link to="/">Home</router-link></span>
            <span>Cart</span>
          </p>
          <h1 class="mb-0 bread">My Cart</h1>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
