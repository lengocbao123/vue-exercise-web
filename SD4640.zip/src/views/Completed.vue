<template>
  <section class="ftco-section ftco-cart">
    <div class="container text-center">
      <p class="text-primary">You completed your order</p>
      <router-link to="/">Back to home page</router-link>
    </div>
  </section>
</template>

<script>
export default {};
</script>
