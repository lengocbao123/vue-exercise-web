# vue-exercise-web

[COMPANY TRAINING] VueJS Fundamentals Exercise

# How to run

## Run backend first

`npm run api`

## Run frontend

`npm run serve`

## Run Unit Test (Just one file for learning)

`npm run test:unit`
